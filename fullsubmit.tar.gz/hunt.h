//  Project Identifier: 40FB54C86566B9DDEAB902CC80E8CE85C1C62AAD

// Represents a single coordinate.
struct position {
    bool investigated = false;
    char symbol = '.';
    char prev;
    
};


struct Location {
    int r, c;
};

